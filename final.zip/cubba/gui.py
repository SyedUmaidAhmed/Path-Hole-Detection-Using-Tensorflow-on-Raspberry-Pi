import tkinter as tk
from tkinter import font  as tkfont
import PIL
import smtplib
import threading
from PIL import Image,ImageTk, ImageSequence
from tkinter import messagebox, Label
import time
LARGE_FONT= ("Verdana", 12)
from threading import Thread
import RPi.GPIO as GPIO
import time
from datetime import datetime
import os
import sys
import classificition_three
from tkinter.filedialog import askopenfilename


SMTP_SERVER = 'smtp.gmail.com' #Email Server (don't change!)
SMTP_PORT = 587 #Server Port (don't change!)
GMAIL_USERNAME = 'piwork99@gmail.com' #change this to match your gmail account
GMAIL_PASSWORD = 'ilovepis'  #change this to match your gmail password



class Emailer:
    def sendmail(self, recipient, subject, content):

        #Create Headers
        headers = ["From: " + GMAIL_USERNAME, "Subject: " + subject, "To: " + recipient,
                   "MIME-Version: 1.0", "Content-Type: text/html"]
        headers = "\r\n".join(headers)

        #Connect to Gmail Server
        session = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        session.ehlo()
        session.starttls()
        session.ehlo()

        #Login to Gmail
        session.login(GMAIL_USERNAME, GMAIL_PASSWORD)

        #Send Email & Exit
        session.sendmail(GMAIL_USERNAME, recipient, headers + "\r\n\r\n" + content)
        session.quit

sender = Emailer()


class CarGUI(tk.Tk):

    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self, *args, **kwargs)
        
        self.title('Pothole Detection')

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")

        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand = True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, PageOne, PageTwo):

            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, cont):

        frame = self.frames[cont]
        frame.tkraise()


class StartPage(tk.Frame):


    def goTopageOne(self,data=None):
        self.controller.show_frame("PageOne")


    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        self.controller = controller

        global button_script, canvas
        
        


        canvas = tk.Canvas(self, bg= "white", width=600,height=300)
        canvas.pack(fill=tk.BOTH, expand=tk.YES)

        def distancer(data=None):
            os.system('python3 /home/pi/cubba/check_ir.py')

        def ML(data=None):
            os.system('python3 main.py')
 
        def GL(data=None):
            os.system('python3 check_2.py')


        def quitting(data=None):
            app.destroy()

	
        def cheese(data=None):
            print("Ask the File")
            filename = askopenfilename() # show an "Open" dialog box and return the path to the selected file
            print(filename)
            classificition_three.classification(filename)
            
            
            fenetre2=tk.Toplevel()
            canvas2 = tk.Canvas(fenetre2, bg= "white", width=600,height=300)
            canvas2.pack(fill=tk.BOTH, expand=tk.YES)
            
            back = Image.open(filename)
            canvas2.image_back=ImageTk.PhotoImage(back)
            back = canvas2.create_image(0,0, image=canvas2.image_back, anchor='nw')
            
            canvas2.create_text(120,40, text='Danger Holes', fill='red', font=("Times 20 bold"))






        back_g = Image.open('/home/pi/potholes.jpg')
        canvas.image_back_g =ImageTk.PhotoImage(back_g)
        back_g = canvas.create_image(0,0, image=canvas.image_back_g, anchor='nw')
        
        button = tk.Button(canvas, bg='white',relief='raised', fg='red', text="Distance Approach",font=("Times 15 bold italic"), width=30, bd=3,command=distancer)
        button.place(x=20, y=10)

        button2 = tk.Button(canvas, bg='white',relief='raised', fg='red', text="Tensorflow with ML", font=("Times 15 bold italic"),bd=3, width=30, command=ML)
        button2.place(x=20, y=70)

        button3 = tk.Button(canvas, bg='white',relief='raised', fg='red', text="Check Images", font=("Times 15 bold italic"), width=30, bd=3, command=cheese)
        button3.place(x=20, y=130)

        button5 = tk.Button(canvas, bg='white',relief='raised', fg='red', text="Cloud Storage", font=("Times 15 bold italic"), width=30, bd=3, command=GL)
        button5.place(x=20, y=190)


        button4 = tk.Button(canvas, bg='white',relief='raised', fg='red', text="Quit", font=("Times 15 bold italic"), width=30, bd=3, command=quitting)
        button4.place(x=20, y=250)




        def apna_hurry(data=None):
            sendTo = 'm.amir.khan359@gmail.com'
            emailSubject = "SAFE ALERT"
            emailContent = "I am fine there is no need of Rescue " + time.ctime() + "SAFE RESPOND"
            sender.sendmail(sendTo, emailSubject, emailContent)
            print("Email Sent")





class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

    def goTopageTwo(self,data=None):
        self.controller.show_frame("PageTwo")


class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)




class myThread (threading.Thread):
    def run(self):
        print("abc")

if __name__ == "__main__":
    file = open("Collect_DEPTH.txt","r+")
    file. truncate(0)
    file. close()
    os.system('rm /home/pi/cubba/approach/*')
    os.system('rm /home/pi/cubba/pic_path_hole/*')


    app = CarGUI()
    app.mainloop()