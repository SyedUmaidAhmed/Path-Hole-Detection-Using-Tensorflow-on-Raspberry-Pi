from firebase import firebase
import base64
import glob, os
from PIL import Image

firebase = firebase.FirebaseApplication('https://striped-harbor-275119.firebaseio.com/', None)






def get_base64_encoded_image(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode('utf-8')

global p
p = 0
os.chdir("/home/pi/cubba/pic_path_hole/")
for file in sorted(glob.glob("*.jpg")):
    print(file)
    im = Image.open(file)
    width, height = im.size
    
    cost = 50.00
    cost = float(cost)

    real = (os.path.splitext(file)[0])
    a = get_base64_encoded_image(file)
    b = '/Potholeinfo/Damage'+ str(real)

    width = width * 0.0264583333
    height = height * 0.0264583333	    

    file1 = open('/home/pi/cubba/Collect_DEPTH.txt')
    lines=file1.readlines()

    cost = (float(lines[p]) * width) * cost
    val = 'pothole' + str(p)
    print(val)
    
    data =  { 'name': val ,'Depth': lines[p].replace('\n', ''), 'Height': height, 'width': width, 'imageURL': a, 'Cost': cost}
    print(lines[p])
    result = firebase.put('',b,data)
    p+=1
    
    